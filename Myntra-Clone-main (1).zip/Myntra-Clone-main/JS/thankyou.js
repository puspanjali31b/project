var goBack = document.querySelector(".go-home");
goBack.addEventListener("click", () => {
  window.location.href = "../index.html";
});
